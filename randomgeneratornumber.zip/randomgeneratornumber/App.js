import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';

const colors = {
  backOrange:"#FB8B24",
  backPink:"#D90368",
  backViolet:"#820263",
  textBlack:"#291720",
  textGreen:"#04A777"
}

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      randomNumber: null,
    };
  }

  generateRandomNumber = () => {
    const min = 1;
    const max = 100;
    const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    this.setState({ randomNumber });
  };

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.heading}>
        Generate Random Number 
        </Text>
        <TouchableOpacity
          style={styles.button}
          onPress={this.generateRandomNumber}>
          <Text style={styles.buttonText}>Random Number</Text>
        </TouchableOpacity>
        {this.state.randomNumber && (
          <Text style={styles.randomNumber}>
            Number is: {this.state.randomNumber}
          </Text>
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor:colors.backOrange,
  },
  button: {
    backgroundColor:colors.backPink,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color:colors.backViolet,
    fontSize: 18,
    fontWeight: 'bold',
  },
  randomNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color:colors.textGreen,
  },
  heading: {
    fontSize: 26,
    marginBottom: 20,
    color:colors.textBlack,
    fontWeight: 'bold',
  },
});

export default App;
